@extends('layouts.app')


@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Insertion</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ url()->previous() }}"> Back</a>
            </div>
        </div>
    </div>

    @if ($errors->any())
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if ($message = Session::get('success'))
        <div class="alert alert-success mt-2">
            <p>{{ $message }}</p>
        </div>
    @endif

    @if ($message = Session::get('error'))
        <div class="alert alert-danger mt-2">
            <p>{{ $message }}</p>
        </div>
    @endif

    <form method="POST" action="{{route('insertions.store')}}">
    	@csrf

         <div class="row mt-3">
            <input name="user_id" id="user_id" type="hidden" value="{{Auth::user()->id}}" >
            
            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Job ID:</strong>
		            <input type="text" name="job_id" id="job_id" class="form-control" placeholder="Job ID">
		        </div>
		    </div>

            <div class="row mb-2">
                <div class="form-group col-xs-8 col-sm-8 col-md-8">
                    <strong id="company">Company:</strong>                    
                        
                </div>
            
                <div class="col-xs-4 col-sm-4 col-md-4 pt-3">
                    <a href="#" id="addCompany"><img src="https://img.icons8.com/avantgarde/50/000000/add.png"/></a>
                </div>
            </div>

            {{-- MODAL --}}
            
            <!-- Modal -->
            <div class="modal fade" id="companyModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Company</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form method="POST">
                            @csrf
                            <div>
                                <strong>Name:</strong>
                                <input type="text" name="nameModal" id="nameModal" class="form-control" placeholder="Name">
                            </div>
                            
                            <div>
                                <strong>Abbreviation:</strong>
                                <input type="text" name="abbreviationModal" id="abbreviationModal" class="form-control" placeholder="Abbreviation">
                            </div>
                            
                            <button type="button" class="btn btn-primary mt-2" id="addModal">Save</button>
                        </form>
                    </div>
                    
                    
                    
                </div>
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mb-2" id="divMedia">
		        <div class="form-group">
		            <strong>Media:</strong>
                    @php
                        $all_media = App\Models\Media::all();
                        
                    @endphp
                    @if (isset($all_media[0]))
                    <select class="form-select" aria-label="Media select" id="media" name="media">
                        <option selected disabled>Select media</option>
                            @foreach ($all_media as $media)
                                <option value="{{$media}}">{{$media->name}}</option>
                            @endforeach
                    </select>   
                        @else
                        <p>No Media added</p>
                    @endif
		            
		        </div>
		    </div> 

		    <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Brand:</strong>
		            <input type="text" name="brand" id="brand" class="form-control" placeholder="Brand">
		        </div>
		    </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Comment:</strong>
		            <input type="text" name="comment" id="comment" class="form-control" placeholder="Comment">
		        </div>
		    </div>


            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Quantity:</strong>
		            <input type="number" name="quantity" id="quantity" class="form-control" placeholder="Quantity">
		        </div>
		    </div>

		    <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Fare:</strong>
		            <input type="text" name="fare" id="fare" class="form-control" placeholder="Fare">
		        </div>
		    </div>

            {{-- A VOIR SI ON LE GERE EN BACK OU SI L'USER L'INDIQUE LUI MEME --}}
            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Invoiced:</strong>
                    @php
                        $all_status = App\Models\InvoiceStatus::all();
                    @endphp

                    @if (isset($all_status[0]))
                    <select class="form-select" aria-label="Invoiced select" id="invoiced" name="invoiced">
                        <option selected disabled>Select Invoice Status</option>
                            @foreach ($all_status as $status)

                                <option value="{{$status->name}}">{{$status->name}}</option>
                            @endforeach
                    </select>   
                        @else
                        <p>No Invoice status Added</p>
                    @endif
		            
		        </div>
		    </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Invoice Nr:</strong>
		            <input type="text" name="invoice_nr" id="invoice_nr" class="form-control" placeholder="Invoice Nr">
		        </div>
		    </div>

            <div class="col-xs-12 col-sm-12 col-md-12 mb-2">
		        <div class="form-group">
		            <strong>Year:</strong>
		            <input type="text" name="year" id="year" class="form-control" placeholder="Year">
		        </div>
		    </div>

		    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
		            <button type="submit" class="btn btn-primary" id="add">Submit</button>
		    </div>
		</div>
    </form>

    <script>
    // FUNCTIONS
    
    //SELECT COMPANY
    function getCompany(){
        $.ajax({
            "url": "/ajax/companies/index",
            "type": "GET",
            success: function(data){
                let option = '<select class="form-select" aria-label="Company select" id="selectCompany" name="company"><option selected disabled>Select the company</option>'

                data.forEach(element =>
                    option += "<option value="+element.name+">"+element.name+"</option>"
                );

                $('#company').after(option);

            },
            error: function(error){
                console.log(error);
            }
        });
    }

    function getIssue(){
        let mediaInput = $('#media').val();
        mediaInput = JSON.parse(mediaInput);
        let mediaId = mediaInput.id;
        
        $.ajax({
            type: 'post',
            url: '/ajax/issue/get',
            data: {
                "_token": "{{ csrf_token() }}",
                media:mediaId,
            },
            success: function (response) {
                let issue = '<div class="col-xs-12 col-sm-12 col-md-12 mb-2 issue"><div class="form-group"><strong>Issue Nr:</strong><select class="form-select" aria-label="Default select example" name="issue_nr" id="issue_nr"><option selected disabled>Select issue</option>' ; 
                
                response.forEach(element => {
                    issue += "<option value='"+element['final_issue']+"'>"+element['final_issue']+"</option>";
                });

                issue += '</select></div></div>';

                $('#divMedia').after(issue);
            },
            error: function (e){
                console.log(e)
            }
        });
    }


    //WHEN DOCUMENT IS READY
    
    $(document).ready(function(){
        // DISPLAY ONLY MONTH IN INPUT MONTH
        $("#month").datepicker({
            format: "mm",
            viewMode: "months", 
            minViewMode: "months",
            multidate: true,
            multidateSeparator: "/",
        });

        // DISPLAY ONLY YEAR IN INPUT YEAR
        $("#year").datepicker({
            format: "yyyy",
            viewMode: "years", 
            minViewMode: "years",
            autoclose:true 
        });

        getCompany();
        
    });

    // DISPLAY TYPE & PLACEMENT INPUTS
    $('#media').change(function(){
        $('.types').remove();
        $('.placements').remove();
        $('.issue').remove();
        
        getIssue();

        let media = $('#media').val();
        media = JSON.parse(media);
        let mediaName = media.name;

        let typeString = media.type;
        let type = typeString.split(",");

        let placementString = media.placement;
        let placement = placementString.split(",");

        if (placement[0] != ""){
            let select = '<div class="col-xs-12 col-sm-12 col-md-12 mb-2 placements"><div class="form-group"><strong>Placement:</strong><select class="form-select" aria-label="Default select example" name="placement" id="placement"><option selected disabled>Select placement</option>'

            placement.forEach(element => {
                select += "<option value='"+element.trim()+"'>"+element.trim()+"</option>";
            });

            select += '</select></div></div>'

            $('#divMedia').after(select);
        }

        if (type[0] != ""){
            
            let select = '<div class="col-xs-12 col-sm-12 col-md-12 mb-2 types"><div class="form-group"><strong>Type:</strong><select class="form-select" aria-label="Default select example" name="type" id="type"><option selected disabled>Select type</option>'

            type.forEach(element => 
                select += "<option value='"+element.trim()+"'>"+element.trim()+"</option>"
            );

            select += '</select></div></div>'

            $('#divMedia').after(select);
        }
    });

    //DISPLAY COMPANY MODAL + STORE
    $('#addCompany').click(function(){
        $('#companyModal').modal('show');
        $('#addModal').on('click', function(e){
            e.preventDefault();
            $.ajax({
                url:"/ajax/companies/store",
                type: "post",
                data: {
                    "_token": "{{ csrf_token() }}",
                    name: $('#nameModal').val(),
                    abbreviation: $('#abbreviationModal').val(),
                },
                success: function (result){
                    $('#selectCompany').remove();
                    getCompany();
                    $('#companyModal').modal('hide');
                }, 
                error: function(error){
                    console.log(error);
                }
            })
        })
    });

    


    // STORE 
    // $(document).ready(function(){
    //     $('#add').on('click', function(e){
    //         let media = JSON.parse($('#selectMedia').val());
    //         let mediaName = media.name;
            
    //         let company = JSON.parse($('#selectCompany').val());
    //         let companyName = company.name;
            
    //         e.preventDefault();
    //         $.ajax({
    //             url: "/insertions",
    //             type: 'post',
    //             data: {
    //                 "_token" : "{{ csrf_token() }}",
    //                 user_id : $('#user_id').val(),
    //                 job_id : $('#job_id').val(),
    //                 company : companyName,
    //                 brand : $('#brand').val(),
    //                 comment : $('#comment').val(),
    //                 media : mediaName,
    //                 type : $('#type').val(),
    //                 placement : $('#placement').val(),
    //                 month : $('#month').val(),
    //                 issue_nr : $('#issue_nr').val(),
    //                 number_of_pages: $('#number_of_pages').val(),
    //                 quantity : $('#quantity').val(),
    //                 fare : $('#fare').val(),
    //                 invoiced : $('#invoiced').val(),
    //                 year : $('#year').val(),
    //             },
    //             success: function(result){
    //                 console.log(result);
    //             },
    //             error: function(error){
    //                 console.log(mediaName);
    //             }
    //         });
    //     });
    // });
    </script>
@endsection