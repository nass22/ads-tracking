<?php

namespace App\Http\Controllers;

use DateTime;
use App\Models\Media;
use App\Models\IssueNrs;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class IssueNrsController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:issue_nrs-list|issue_nrs-create|issue_nrs-edit|issue_nrs-delete|issue_nrs-export', ['only' => ['index','show']]);
         $this->middleware('permission:issue_nrs-create', ['only' => ['create','store']]);
         $this->middleware('permission:issue_nrs-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:issue_nrs-delete', ['only' => ['destroy']]);
         $this->middleware('permission:issue_nrs-export', ['only' => ['export']]);
    }

    public function index(){
        $all_issue = IssueNrs::latest()->simplePaginate(10);
        return view('issueNr.index', compact('all_issue'));
    }

    public function create(){
        return view('issueNr.create');
    }
    public function store(Request $request, IssueNrs $issue){
        // request()->validate([
        //     'media' => 'required',
        //     'numero' => 'required',
        //     'date' => 'required',
        // ]);

        $mediaInput = json_decode($request->media);
        $mediaName = $mediaInput->name;
        $media = Media::where('name', $mediaName)->first();
        
        $media_id = $media->id;
        $media_abbre = $media->abbreviation;
        
        
        
        if ($mediaName == "Tempo Focus" || $mediaName == "Tempo Congress"){
            $issue->user_id = $request->user_id;
            $issue->media_id = $media_id;
            $issue->media = $mediaName;
            $issue->numero = strtoupper($request->numero);
            $issue->year = $request->year;
            $issue->month = $request->month;
            $issue->final_issue = $media_abbre . "-" . strtoupper($request->numero) . "_" .  substr($request->year, -2) . $request->month;

            $issue->save();
        } elseif ($mediaName == "Tempo Medical" || $mediaName == "BJP"){
            $issue->user_id = $request->user_id;
            $issue->media_id = $media_id;
            $issue->media = $mediaName;
            $issue->numero = $request->numero;
            $issue->year = $request->year;
            $issue->month = $request->month;
            $issue->final_issue = $media_abbre . $request->numero . "_" . substr($request->year, -2) . $request->month;

            $issue->save();
        } elseif ($mediaName == "Tempo Today" || $mediaName == "Tempo Week-end" || $mediaName == "eMail"){
            $date = $request->week;
            $newDate = new DateTime($date);
            $week = $newDate->format('W');
            
            $dateParse =date_parse($date);
            if($dateParse['month'] < 10){
                $dateParse['month'] = "0" . $dateParse['month'];
            }

            if($dateParse['day'] < 10){
                $dateParse['day'] = "0" . $dateParse['day'];
            }
            
            $issue->user_id = $request->user_id;
            $issue->media_id = $media_id;
            $issue->media = $mediaName;
            $issue->year = $dateParse['year'];
            $issue->month = $dateParse['month'];
            $issue->day = $dateParse['day'];
            $issue->week = $week;
            $issue->final_issue = $media_abbre . "_" . substr($dateParse['year'], -2) . $dateParse['month'] . $dateParse['day'] . "_" . $week;

            $issue->save();
        } else {
            $issue->user_id = $request->user_id;
            $issue->media_id = $media_id;
            $issue->media = $mediaName;
            $issue->year = $request->year;
            $issue->month = $request->month;
            $issue->final_issue = $media_abbre . "_" . substr($request->year, -2) . $request->month;

            $issue->save();
        }
        
        return redirect()->route('issue_nr.index');
    }

    public function destroy(IssueNrs $issue_nr)
    {
        $issue_nr->delete();
        Alert::success('success','Issue Nr deleted successfully');

        return redirect()->route('issue_nr.index');
    } 
}
