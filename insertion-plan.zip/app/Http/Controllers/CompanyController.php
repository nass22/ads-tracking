<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\TryCatch;
use RealRashid\SweetAlert\Facades\Alert;

class CompanyController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:companies-list|companies-create|companies-edit|companies-delete|companies-export', ['only' => ['index','show']]);
         $this->middleware('permission:companies-create', ['only' => ['create','store']]);
         $this->middleware('permission:companies-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:companies-delete', ['only' => ['destroy']]);
         $this->middleware('permission:companies-export', ['only' => ['export']]);
    }

    public function index()
    {
        $companies = Company::latest()->simplePaginate(10);
        return view('companies.index',compact('companies'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function create()
    {
        return view('companies.create');
    }

    public function store(Request $request)
    {
        request()->validate([
            'name' => 'required',
            'abbreviation' => 'required'
        ]);
        try {
            Company::create([
                'name' => $request->name,
                'abbreviation' => Str::upper($request->abbreviation)
            ]);
            Alert::success('Success','Company created successfully.');

            return redirect()->route('companies.index');

        } catch (\Throwable $th) {
            Alert::error('Error', 'This abbreviation already exists! Please enter another abbreviation.');

            return back()->withInput();
        }
    }

    
    public function edit(Company $company)
    {
        return view('companies.edit',compact('company'));
    }

    public function update(Request $request, Company $company)
    {
         request()->validate([
            'name' => 'required',
            'abbreviation' => 'required',
        ]);
    
        $company->update($request->all());
        
        return redirect()->route('companies.index')
                        ->with('success','Company updated successfully');
    }

    public function destroy(Company $company)
    {
        $company->delete();
    
        return redirect()->route('companies.index')
                        ->with('success','Company deleted successfully');
    }

}
