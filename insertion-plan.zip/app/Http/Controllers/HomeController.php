<?php

namespace App\Http\Controllers;

use DataTables;
use App\Models\Insertion;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {   
        if ($request->ajax()) {
            
            if ($request->get('check') == "false") {
                $data = Insertion::where('invoiced', 'no')->orWhere('invoiced', 'tib')->get();
            } else {
                $data = Insertion::all();
            }
            
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->filter(function ($instance) use ($request) {
                        if (!empty($request->get('search'))) {
                            
                            $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                                
                                if (Str::contains(Str::lower($row['id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['job_id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['company']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['brand']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['comment']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['media']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['type']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['placement']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['issue_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['quantity']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['fare']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoiced']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoice_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['year']), Str::lower($request->get('search')))) {
                                    return true;
                                }
                                return false;
                            });
                        }
                    })
                    ->addColumn('action', function($row){
                        $siteEdit= route('insertions.edit',$row->id);
                        $siteDelete = route('insertions.destroy', $row->id);
                       
                        $btn = '
                        <a href="'. $siteEdit .'" class="edit btn btn-primary btn-sm" target="_blank">Edit</a>
                        <form action="' . $siteDelete. '" method="POST">
                        '.csrf_field().'
                        '.method_field("DELETE").'
                        <button type="submit" class="btn btn-danger delete-confirm">Delete</button>
                        </form>';

                        

                        $insertion = Insertion::where('id', $row->id)->first();

                        if($insertion->user_id == Auth::user()->id || Str::lower(Auth::user()->role) == "admin"){
                            return $btn;
                        }
                        
                        
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        
        return view('home');
    }
}