<?php
    
namespace App\Http\Controllers;

use DataTables;
use App\Models\Insertion;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
    
class InsertionController extends Controller
{ 
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
         $this->middleware('permission:insertions-list|insertions-create|insertions-edit|insertions-delete|insertions-export', ['only' => ['index','show']]);
         $this->middleware('permission:insertions-create', ['only' => ['create','store']]);
         $this->middleware('permission:insertions-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:insertions-delete', ['only' => ['destroy']]);
         $this->middleware('permission:insertions-export', ['only' => ['export']]);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            
            if ($request->get('check') == "false") {
                $data = Insertion::where('invoiced', 'no')->orWhere('invoiced', 'tib')->get();
            } else {
                $data = Insertion::all();
            }
            
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->filter(function ($instance) use ($request) {
                        if (!empty($request->get('search'))) {
                            
                            $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                                
                                if (Str::contains(Str::lower($row['id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['job_id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['company']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['brand']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['comment']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['media']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['type']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['placement']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['issue_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['quantity']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['fare']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoiced']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoice_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['year']), Str::lower($request->get('search')))) {
                                    return true;
                                }
                                return false;
                            });
                        }
                    })
                    ->addColumn('action', function($row){
                        $siteEdit= route('insertions.edit',$row->id);
                        $siteDelete = route('insertions.destroy', $row->id);
                       
                        $btn = '
                        <a href="'. $siteEdit .'" class="edit btn btn-primary btn-sm" target="_blank">Edit</a>
                        <form action="' . $siteDelete. '" method="POST">
                        '.csrf_field().'
                        '.method_field("DELETE").'
                        <button type="submit" class="btn btn-danger delete-confirm">Delete</button>
                        </form>';

                        

                        $insertion = Insertion::where('id', $row->id)->first();

                        if($insertion->user_id == Auth::user()->id || Str::lower(Auth::user()->role) == "admin"){
                            return $btn;
                        }
                        
                        
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        
        return view('home');
    }
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('insertions.create');
    }
    
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        request()->validate([
            'job_id' => 'required',
            'company' => 'required',
            'media' => 'required',
            'issue_nr' => 'required',
            'type' => 'nullable',
            'placement' => 'nullable',
            'brand' => 'nullable',
            'comment' => 'nullable',
            'quantity' => 'required|integer',
            'fare' => 'required',
            'invoice_nr' => 'nullable',
            'invoiced' => 'nullable',
            'year' => 'required',
        ]);
        
        $media = json_decode($request->media);
        $mediaName = $media->name;
        
        try {
            $insertion = new Insertion;
            $insertion->user_id = $request->user_id;
            $insertion->job_id = $request->job_id;
            $insertion->company = $request->company;
            $insertion->media = $mediaName;
            $insertion->issue_nr = $request->issue_nr;
            $insertion->type = $request->type;
            $insertion->placement = $request->placement;
            $insertion->brand = $request->brand;
            $insertion->comment = $request->comment;
            $insertion->quantity = $request->quantity;
            $insertion->fare = $request->fare;
            $insertion->invoice_nr = $request->invoice_nr;

            if($request->invoice_nr != null){
                $insertion->invoiced = "YES";
                $insertion->status = "CLOSE";
            } else {
                // A MODIF SI ON GENRE LE STATUS EN BACK -> $insertion->invoiced = "NO";
                $insertion->invoiced = $request->invoiced;
                $insertion->status = "OPEN";
            }

            $insertion->year = $request->year;
            $insertion->save();
            
            return redirect()->route('insertions.index')
                            ->with('success','Insertion created successfully.');
        } catch (\Throwable $th) {
            return back()->with('error', $th->getMessage())->withInput();
        }
    }
    
    /**
     * Display the specified resource.
     *
     * @param  \App\Insertion  $insertion
     * @return \Illuminate\Http\Response
     */
    public function show(Insertion $insertion)
    {
        return view('insertions.show',compact('insertion'));
    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Insertion  $insertion
     * @return \Illuminate\Http\Response
     */
    public function edit(Insertion $insertion)
    {

        return view('insertions.edit',compact('insertion'));
    }
    
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Insertion  $insertion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Insertion $insertion)
    {
        request()->validate([
            'job_id' => 'required',
            'company' => 'required',
            'media' => 'required',
            'issue_nr' => 'required',
            'type' => 'nullable',
            'placement' => 'nullable',
            'brand' => 'nullable',
            'comment' => 'nullable',
            'quantity' => 'required|integer',
            'fare' => 'required',
            'invoice_nr' => 'nullable',
            'invoiced' => 'nullable',
            'year' => 'required',
        ]);

        $media = json_decode($request->media);
        $mediaName = $media->name;

        $insertion->user_id = $request->user_id;
        $insertion->job_id = $request->job_id;
        $insertion->company = $request->company;
        $insertion->media = $mediaName;
        $insertion->issue_nr = $request->issue_nr;
        $insertion->type = $request->type;
        $insertion->placement = $request->placement;
        $insertion->brand = $request->brand;
        $insertion->comment = $request->comment;
        $insertion->quantity = $request->quantity;
        $insertion->fare = $request->fare;
        $insertion->invoice_nr = $request->invoice_nr;

        if($request->invoice_nr != null){
            $insertion->invoiced = "YES";
            $insertion->status = "CLOSE";
        } else {
            // A MODIF SI ON GENRE LE STATUS EN BACK -> $insertion->invoiced = "NO";
            $insertion->invoiced = $request->invoiced;
            $insertion->status = "OPEN";
        }

        $insertion->year = $request->year;
        $insertion->update();

        return redirect()->route('insertions.index')
                        ->with('success','Insertion updated successfully');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Insertion  $insertion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Insertion $insertion)
    {   
        $insertion->delete();
    
        return redirect()->route('insertions.index')
                        ->with('success','Insertion deleted successfully');

        // try {
        //     if(Auth::user()->id == $insertion->user_id || Str::lower(Auth::user()->role) == "admin"){
        //         $insertion->delete();
    
        //         return redirect()->route('insertions.index')
        //                         ->with('success','Insertion deleted successfully');
        //     } else {
        //         return back()->with('error', 'You are not Admin!');
        //     }
        // } catch (\Throwable $th) {
        //     return back()->with($th->getMessage());
        // }
        
    }

    public function myInsertions(Request $request){
        $user_id = Auth::user()->id;
        
        if ($request->ajax()) {
           
            if ($request->get('check') == "false") {
                $data = Insertion::where('user_id', $user_id)->where('invoiced', 'TIB')->orWhere('invoiced', 'NO')->get();
            } else {
                $data = Insertion::where('user_id', $user_id)->get();
            }

            return Datatables::of($data)
                    ->addIndexColumn()
                    ->filter(function ($instance) use ($request) {
                        if (!empty($request->get('search'))) {
                            
                            $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                                
                                if (Str::contains(Str::lower($row['id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['job_id']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['company']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['brand']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['comment']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['media']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['type']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['placement']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['issue_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['quantity']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['fare']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoiced']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['invoice_nr']), Str::lower($request->get('search')))) {
                                    return true;
                                } else if (Str::contains(Str::lower($row['year']), Str::lower($request->get('search')))) {
                                    return true;
                                }
                                return false;
                            });
                        }
                    })
                    ->addColumn('action', function($row){
                        $siteEdit= route('insertions.edit',$row->id);
                        $btnEdit = '<a href="'. $siteEdit .'" class="edit btn btn-primary btn-sm" target="_blank">Edit</a>';

                        return $btnEdit;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        
        return view('insertions.personalIns');
    }
}