<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\IssueNrs;
use Illuminate\Http\Request;

class AjaxController extends Controller
{
    public function indexCompany(){
        $companies = Company::all();
        return $companies;
    }

    public function storeCompany(Request $request){
        request()->validate([
            'name' => 'required',
            'abbreviation' => 'required'
        ]);
        
        $company = new Company;
        $company->name = $request->name;
        $company->abbreviation = $request->abbreviation;
        $company->save();
    }

    public function getIssue(Request $request){
        $mediaId = $request->media;
        $year = date("Y");
        
        $all_issue = IssueNrs::where('media_id', $mediaId)->where('year', '>=', $year)->get();
        return $all_issue;
    }
}
