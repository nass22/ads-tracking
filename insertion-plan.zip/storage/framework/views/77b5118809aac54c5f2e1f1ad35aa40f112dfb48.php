


<?php $__env->startSection('content'); ?>
<?php if($insertion->user_id == Auth::user()->id): ?>
	<div class="row">
		<div class="col-lg-12 margin-tb">
			<div class="pull-left">
				<h2>Edit Insertion</h2>
			</div>
			<div class="pull-right">
				<a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>">Back</a>
			</div>
		</div>
	</div>


	<?php if($errors->any()): ?>
		<div class="alert alert-danger">
			<strong>Whoops!</strong> There were some problems with your input.<br><br>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>


	<form action="<?php echo e(route('insertions.update',$insertion->id)); ?>" method="POST">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>

		<div class="row mt-3">
			<input name="user_id" id="user_id" type="hidden" value="<?php echo e(Auth::user()->id); ?>" >
			
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Job ID:</strong>
					<input type="text" name="job_id" value="<?php echo e($insertion->job_id); ?>" class="form-control" placeholder="Job ID">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2">
				<div class="form-group">
					<strong>Company:</strong>
					<?php
						$companies = App\Models\Company::all();
					?>

					<?php if(isset($companies[0])): ?>
						<select class="form-select" aria-label="Company select" name="company">
							<option selected disabled>Select Company</option>
								<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($company->name); ?>" <?php echo e($insertion->company == $company->name ? 'selected' : ''); ?>><?php echo e($company->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>   
					<?php else: ?>
						<p>No Company Name Added</p>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2" id="mediaDiv">
				<div class="form-group">
					<strong>Media:</strong>
					<?php
						$all_media = App\Models\Media::all();
					?>

					<?php if(isset($all_media[0])): ?>
						<select class="form-select" aria-label="Media select" name="media" id="media">
							<option selected disabled>Select Media</option>
								<?php $__currentLoopData = $all_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($media); ?>" <?php echo e($insertion->media == $media->name ? 'selected' : ''); ?>><?php echo e($media->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>   
					<?php else: ?>
						<p>No Media Added</p>
					<?php endif; ?>
				</div>
			</div>

			<?php if(isset($insertion->type)): ?>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2" id="typeDiv">
				<div class="form-group">
					<strong>Type:</strong>
					<?php
						$media = App\Models\Media::where('name', $insertion->media)->first();
						$all_type = $media->type;
						$all_type = explode(",", $all_type);
					?>

					<?php if(isset($all_type[0])): ?>
						<select class="form-select" aria-label="Type select" name="type" >
							<option selected disabled>Select Type</option>
								<?php $__currentLoopData = $all_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($type); ?>" <?php echo e($insertion->type == $type ? 'selected' : ''); ?>><?php echo e($type); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>   
					<?php else: ?>
						<p>No Type Added</p>
					<?php endif; ?>
				</div>
			</div>
				
			<?php endif; ?>

			<?php if(isset($insertion->placement)): ?>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2" id="placementDiv">
				<div class="form-group">
					<strong>Placement:</strong>
					<?php
						$media = App\Models\Media::where('name', $insertion->media)->first();
						$all_placement = $media->placement;
						$all_placement = explode(",", $all_placement);
					?>

					<?php if(isset($all_placement[0])): ?>
						<select class="form-select" aria-label="Placement select" name="placement" >
							<option selected disabled>Select Placement</option>
								<?php $__currentLoopData = $all_placement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $placement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($placement); ?>" <?php echo e($insertion->placement == $placement ? 'selected' : ''); ?>><?php echo e($placement); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>   
					<?php else: ?>
						<p>No Placement Added</p>
					<?php endif; ?>
				</div>
			</div>
				
			<?php endif; ?>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Issue Nr:</strong>
					<input type="text" name="issue_nr" value="<?php echo e($insertion->issue_nr); ?>" class="form-control" placeholder="Issue Nr">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Brand:</strong>
					<input type="text" name="brand" value="<?php echo e($insertion->brand); ?>" class="form-control" placeholder="Brand">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Comment:</strong>
					<input type="text" name="comment" value="<?php echo e($insertion->comment); ?>" class="form-control" placeholder="Comment">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Quantity:</strong>
					<input type="text" name="quantity" value="<?php echo e($insertion->quantity); ?>" class="form-control" placeholder="Quantity">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Fare:</strong>
					<input type="text" name="fare" value="<?php echo e($insertion->fare); ?>" class="form-control" placeholder="Fare">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2">
				<div class="form-group">
					<strong>Invoice Nr:</strong>
					<input type="text" name="invoice_nr" value="<?php echo e($insertion->invoice_nr); ?>"class="form-control" placeholder="Invoice Nr">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12 mb-2">
				<div class="form-group">
					<strong>Invoiced:</strong>
					<?php
						$all_status = App\Models\InvoiceStatus::all();
					?>

					<?php if(isset($all_status[0])): ?>
						<select class="form-select" aria-label="Invoiced select" id="invoiced" name="invoiced">
							<option selected disabled>Select Invoice Status</option>
								<?php $__currentLoopData = $all_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

									<option value="<?php echo e($status->name); ?>" <?php echo e($insertion->invoiced == $status->name ? 'selected' : ''); ?>><?php echo e($status->name); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>   
					<?php else: ?>
						<p>No Invoice status Added</p>
					<?php endif; ?>
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="form-group">
					<strong>Year:</strong>
					<input type="text" id="year" name="year" value="<?php echo e($insertion->year); ?>" class="form-control" placeholder="year">
				</div>
			</div>

			<div class="col-xs-12 col-sm-12 col-md-12 text-center mt-3">
			<button type="submit" class="btn btn-primary" id='add'>Submit</button>
			</div>
		</div>

	</form>
<?php else: ?> 
	<div class="alert alert-danger">
		<strong>Whoops!</strong> Nice try...<br><br>
		<ul>
			
				<li>Your are not admin!</li>
			
		</ul>
	</div>
<?php endif; ?>
    
    <script>
        
        $(document).ready(function(){
			// DISPLAY ONLY MONTH IN INPUT MONTH
			$("#month").datepicker({
            format: "mm",
            viewMode: "months", 
            minViewMode: "months",
            multidate: true
        	});

			// DISPLAY ONLY YEAR IN CALENDAR
            $("#year").datepicker({
                format: "yyyy",
                viewMode: "years", 
                minViewMode: "years",
                ultidate: true
            });

			// DISPLAY TYPE & PLACEMENT ON MEDIA CHANGE
			$('#media').change(function(){
				let mediaArray = $('#media').val();
				mediaArray = JSON.parse(mediaArray);
				
				let typeString = mediaArray.type;
				let typeArray = typeString.split(",");

				let placementString = mediaArray.placement;
				let placementArray = placementString.split(",");

				$('#typeDiv').remove();
				$('#placementDiv').remove();

				if(placementArray != ""){
					let html = "<div class='col-xs-12 col-sm-12 col-md-12 mb-2' id='placementDiv'><div class='form-group'><strong>Placement:</strong><select class='form-select' aria-label='Placement select' name='placement'><option selected>Select Placement</option>"

						placementArray.forEach(element => {
							html += "<option value='"+element+"'}>"+element+"</option>"
						});

					html += "</select>";

					$('#mediaDiv').after(html);
				}

				if(mediaArray.type != ""){
					let html = "<div class='col-xs-12 col-sm-12 col-md-12 mb-2' id='typeDiv'><div class='form-group'><strong>Type:</strong><select class='form-select' aria-label='Type select' name='type'><option selected>Select Type</option>";

						typeArray.forEach(element => {
							html += "<option value='"+element+"'}>"+element+"</option>"
						});

					html += "</select>";

					$('#mediaDiv').after(html);
				}
			});

        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/insertions/edit.blade.php ENDPATH**/ ?>