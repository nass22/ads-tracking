

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New Media</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('medias.index')); ?>">Back</a>
            </div>
        </div>
    </div>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success mt-2">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger mt-2">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <div class="alert alert-success" style="display:none"></div>

    <form method="POST" action="<?php echo e(route('medias.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="row mt-3">
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label"><b>Media name</b></label>
                <input type="text" class="form-control" placeholder="Ex: Tempo Medical" name="name" id="name">
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label"><b>Abbreviation</b></label>
                <input type="text" class="form-control" placeholder="Ex: TM" name="abbreviation" id="abbreviation">
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label"><b>Type</b> (If more than one, separate with a comma!)</label>
                <input type="text" class="form-control" placeholder="Ex: AD 1/1, AD 1/2, ..." name="type" id="type">
            </div>

            <div class="mb-3" id="placementDiv">
                <label for="exampleFormControlInput1" class="form-label"><b>Placement</b> (If more than one, separate with a comma!)</label>
                <input type="text" class="form-control" placeholder="Ex: OverCover, UnderCover, ..." name="placement" id="placement">
            </div>



            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button class="btn btn-primary" id="add">Submit</button>
            </div>
        </div>
    </form>

    <script>
        // ADD NUMERO INPUT
        $('#name').keyup(function(){
            $('#numeroDiv').remove()
            
            let input = $('#name').val().toLowerCase()
            input = input.trim()
            
            if (input == "tempo focus" || input == "tempo congress"){
                
                let numero = '<div class="mb-3" id="numeroDiv"><label for="exampleFormControlInput1" class="form-label pt-2" ><b>Numero</b> (If more than one, separate with a comma!)</label><input type="text" class="form-control" placeholder="Ex: NeuroPsy, Cardio, ..." name="numero" id="numero"></div>'

                $('#placementDiv').after(numero);
            }
        })

        // STORE 
        // $(document).ready(function(){
        //     $('#add').on('click', function(e){
        //         e.preventDefault();

        //         const type = $('#type').val();
        //         const placement = $('#placement').val();
                
        //         const typeArray = type.split(",");
        //         const placementArray = placement.split(",");


        //         $.ajax({
        //             url: "<?php echo e(route('medias.store')); ?>",
        //             type: 'post',
        //             data: {
        //                 "_token" : "<?php echo e(csrf_token()); ?>",
        //                 name : $('#name').val(),
        //                 abbreviation : $('#abbreviation').val(),
        //                 type : JSON.stringify(typeArray),
        //                 placement : JSON.stringify(placementArray)
        //             },
        //             success: function(result){
        //                 console.log(result);
        //                 $('.alert').show();
        //                 $('.alert').html('<p>'+ result.success + '</p>');
        //             }
        //         });
        //     });
        // });
    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/medias/create.blade.php ENDPATH**/ ?>