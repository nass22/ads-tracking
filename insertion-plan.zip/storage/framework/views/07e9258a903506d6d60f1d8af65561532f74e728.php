


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Invoice Status</h2>
        </div>
        <div class="pull-right">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('insertions-create')): ?>
                <a class="btn btn-success" href="<?php echo e(route('invoice_status.create')); ?>"> Create New Invoice Status</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success mt-2">
        <p><?php echo e($message); ?></p>
    </div>
<?php endif; ?>

<table class="table table-bordered mt-3">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th width="280px">Action</th>
    </tr>
    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $one_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->index); ?></td>
        <td><?php echo e($one_status->name); ?></td>
        <td>

            <form action="<?php echo e(route('invoice_status.destroy',$one_status->id)); ?>" method="POST">
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('companies-edit')): ?>
                <a class="btn btn-primary" href="<?php echo e(route('invoice_status.edit',$one_status->id)); ?>">Edit</a>
                <?php endif; ?>


                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('invoice_statuses-delete')): ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                <?php endif; ?>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php echo $status->links(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/invoiceStatus/index.blade.php ENDPATH**/ ?>