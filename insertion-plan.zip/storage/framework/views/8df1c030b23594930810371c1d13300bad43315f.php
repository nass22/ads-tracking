


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Media</h2>
            </div>
            <div class="pull-right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('media-create')): ?>
                <a class="btn btn-success mb-3" href="<?php echo e(route('medias.create')); ?>"> Create New media</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Abbreviation</th>
            <th>Type</th>
            <th>Placement</th>
            <th>Numero</th>
            <th width="280px">Action</th>
        </tr>
	    <?php $__currentLoopData = $all_media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <tr>
	        <td><?php echo e($loop->index); ?></td>
	        <td><?php echo e($media->name); ?></td>
	        <td><?php echo e($media->abbreviation); ?></td>
            <td><?php echo e($media->type); ?></td>
            <td><?php echo e($media->placement); ?></td>
            <td><?php echo e($media->numero); ?></td>
	        <td>
                <form action="<?php echo e(route('medias.destroy',$media->id)); ?>" method="POST">
                    <a class="btn btn-info" href="<?php echo e(route('medias.show',$media->id)); ?>">Show</a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('media-edit')): ?>
                    <a class="btn btn-primary" href="<?php echo e(route('medias.edit',$media->id)); ?>">Edit</a>
                    <?php endif; ?>


                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('media-delete')): ?>
                    <button type="submit" class="btn btn-danger">Delete</button>
                    <?php endif; ?>
                </form>
	        </td>
	    </tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/medias/index.blade.php ENDPATH**/ ?>