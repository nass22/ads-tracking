

<?php $__env->startSection('content'); ?>

<div class="container text-center mt-4 pb-4">
    <a href="<?php echo e(route('insertions.create')); ?>" class="btn btn-warning"><i class="fa-solid fa-circle-plus"></i> <strong>Add New Insertion</strong></a>
</div>

<div class="card mt-4">
    <div class="card-body">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="checkInput" id="checkInput" value="">
            <label class="form-check-label" for="flexCheckDefault">
                Show closed insertions
            </label>
          </div>
    </div>
</div>

<table cellpadding="3" cellspacing="0" border="0" style="width: 67%; margin: 0 auto 2em auto;" class="mt-4">
    <div id="buttons"></div>
<table class="table table-bordered data-table" id="insertionsPersoTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Job ID</th>
            <th>Company</th>
            <th>Brand</th>
            <th>Comment</th>
            <th>Media</th>
            <th>Type</th>
            <th>Placement</th>
            <th>Issue Nr</th>
            <th>Quantity</th>
            <th>Fare</th>
            <th>Invoiced</th>
            <th>Invoice Nr</th>
            <th>Year</th>
            <th>Status</th>
            <th width="100px">Action</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
    <tfoot>
        <tr>
            <th  colspan="10" style="text-align:right"></th>
            <th></th>
        </tr>
    </tfoot>
</table>

<script type="text/javascript">

    //FUNCTIONS

    function datatable() {
        console.log($('#checkInput').is(":checked"));
        var table = $('#insertionsPersoTable').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            paging: true,
            pageLength: 50,
            dom: 'Bfrtip',
            buttons: [
                'pageLength',
                'excelHtml5',
                'pdfHtml5'
            ],
            ajax: {
                url: "<?php echo e(route('my_insertions')); ?>",
                data: function(d){
                    d.search = $('input[type="search"]').val();
                    d.check = $('#checkInput').is(":checked");
                }
            },
            columns: [
                {data: 'id', name: 'id'},
                {data: 'job_id', name: 'job_id'},
                {data: 'company', name: 'company'},
                {data: 'brand', name: 'brand'},
                {data: 'comment', name: 'comment'},
                {data: 'media', name: 'media'},
                {data: 'type', name: 'type'},
                {data: 'placement', name: 'placement'},
                {data: 'issue_nr', name: 'issue_nr'},
                {data: 'quantity', name: 'quantity'},
                {data: 'fare', name: 'fare'},
                {data: 'invoiced', name: 'invoiced'},
                {data: 'invoice_nr', name: 'invoice_nr'},
                {data: 'year', name: 'year'},
                {data: 'status', name: 'status'},
                {data: 'action', name: 'action', orderable: true, searchable: true},
            ],
            "footerCallback": function ( row, data, start, end, display ) {
                var api = this.api(), data;

                // Remove the formatting to get integer data for summation
                var intVal = function ( i ) {
                    return typeof i === 'string' ?
                        i.replace(/[\$,]/g, '')*1 :
                        typeof i === 'number' ?
                            i : 0;
                };

                // Total over ALL pages
                var total = api
                    .column( 10 )
                    .data()
                    .reduce( function (a, b) {
                        return intVal(a) + intVal(b);
                    }, 0 );
                    
                // Update footer
                $( api.column( 9 ).footer() ).html('Total:');
                $( api.column( 10 ).footer() ).html(total+'€');
                
            },
            "fnDrawCallback": function() {
                $('#checkInput').change(function (d) {
                    $('.data-table').DataTable().ajax.reload();
                });
            },
        });
    };

    $(document).ready(function(){
        datatable();
    });

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/insertions/personalIns.blade.php ENDPATH**/ ?>