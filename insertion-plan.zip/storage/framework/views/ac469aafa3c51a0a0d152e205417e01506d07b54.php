


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show Insertion</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(url()->previous()); ?>">Back</a>
            </div>
        </div>
    </div>


    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Author:</strong>
                <?php
                $username = App\Models\User::where('id', $insertion->user_id)->first();
                ?>
                <?php echo e($username->name); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Job ID:</strong>
                <?php echo e($insertion->job_id); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Company:</strong>
                <?php echo e($insertion->company); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Brand:</strong>
                <?php echo e($insertion->brand); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Comment:</strong>
                <?php echo e($insertion->comment); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Media:</strong>
                <?php echo e($insertion->media); ?>

            </div>
        </div>

        <?php if($insertion->type != null): ?>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Type:</strong>
                    <?php echo e($insertion->type); ?>

                </div>
            </div>
        <?php endif; ?>


        <?php if($insertion->placement != null): ?>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Placement:</strong>
                    <?php echo e($insertion->placement); ?>

                </div>
            </div>
        <?php endif; ?>
        
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Month:</strong>
                <?php echo e($insertion->month); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Issue Nr:</strong>
                <?php echo e($insertion->issue_nr); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Quantity:</strong>
                <?php echo e($insertion->quantity); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Fare:</strong>
                <?php echo e($insertion->fare . "€"); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Invoiced:</strong>
                <?php echo e($insertion->invoiced); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Invoice Nr:</strong>
                <?php echo e($insertion->invoice_nr); ?>

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Year:</strong>
                <?php echo e($insertion->year); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\insertion-plan\resources\views/insertions/show.blade.php ENDPATH**/ ?>